<?php

header('Content-Type: text/html; charset=utf-8');

//Hantei, phpkursus2016, 30.04.2016
//Ylesanne 0101

/*

Järgnevas ülesandes tohib kasutada vaid IF tingimust ja FOR tsükklit. Arvude üleühe kuvamiseks kasutage lisamuutujat. Kuvada ühe FOR tsükkliga välja järgmine arvude jada järgmisel kujul: 

1
3
5
7
9
11
13
15
17
19

*/

for ($i=1; $i<=19; $i=$i+2) {
		echo "$i <br>";
}

echo "<br><strong>Ylesanne 0101</strong>";

?>
